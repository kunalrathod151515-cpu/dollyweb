"use client"
import { useState, useEffect } from "react"

const ADMIN_PIN = "DOLLY@2026" // <-- TERA SECRET CREDENTIALS

export default function AdminGate(){
  const [pin,setPin]=useState("")
  const [ok,setOk]=useState(false)
  useEffect(()=>{
    if(localStorage.getItem("dolly_admin_ok")==="yes") setOk(true)
  },[])
  const check=()=>{
    if(pin===ADMIN_PIN){
      localStorage.setItem("dolly_admin_ok","yes")
      setOk(true)
    } else { alert("Wrong Admin PIN!") }
  }
  if(!ok){
    return(
      <div className="min-h-screen bg-[#0f0a0d] text-white flex items-center justify-center p-6">
        <div className="bg-[#1a1218] border border-white/10 rounded-[28px] p-8 w-full max-w-sm text-center">
          <h1 className="text-2xl font-black">👑 Admin Access</h1>
          <p className="text-white/50 text-sm mt-2">Private - Owner Only</p>
          <input value={pin} onChange={e=>setPin(e.target.value)} placeholder="Enter Admin PIN" type="password" className="mt-8 w-full bg-[#2a1e25] rounded-full py-4 px-6 text-center outline-none border border-white/10" />
          <button onClick={check} className="mt-4 w-full bg-[#ff1846] rounded-full py-4 font-bold">Unlock Admin →</button>
          <button onClick={()=>window.location.href="/"} className="mt-3 text-white/30 text-xs">← Back to Launch Page</button>
        </div>
      </div>
    )
  }
  return(
    <div className="min-h-screen bg-[#0f0a0d] text-white p-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-black">Admin Dashboard - PRIVATE</h1>
        <button onClick={()=>{localStorage.removeItem("dolly_admin_ok"); location.reload()}} className="bg-white/10 rounded-full px-4 py-2 text-sm">Logout</button>
      </div>
      <div className="mt-10 bg-[#1a1218] rounded-[20px] p-6 border border-white/10">
        <p className="text-white/60">Welcome Owner! Yahan tera original admin panel ka code ayega.</p>
        <p className="text-white/30 text-xs mt-2">Agar tera pehle wala admin page tha to uska code is file me is div ke neeche paste kar dena.</p>
        <div className="mt-6 grid grid-cols-2 gap-4">
          <div className="bg-[#2a1e25] rounded-xl p-4">Total Tables: 8</div>
          <div className="bg-[#2a1e25] rounded-xl p-4">Total Dishes: 10</div>
        </div>
      </div>
    </div>
  )
}
