"use client"
import { useState } from "react"
import { useRouter } from "next/navigation"

const USERS: any = {
  waiter:  { pass: "WAIT123",    path: "/waiter",  label: "Waiter • Order", icon: "🍽️" },
  kitchen: { pass: "KITCHEN123", path: "/kitchen", label: "Kitchen", icon: "👨‍🍳" },
  manager: { pass: "MANAGER123", path: "/manager", label: "Manager", icon: "👔" },
  admin:   { pass: "DOLLY@2026", path: "/admin",   label: "Admin", icon: "👑" },
}

export default function SecureLogin(){
  const [user,setUser]=useState("waiter")
  const [pin,setPin]=useState("")
  const router=useRouter()
  
  const login=()=>{
    if(USERS[user].pass===pin){
      localStorage.setItem("dolly_role",user)
      localStorage.setItem("dolly_ok","yes")
      router.push(USERS[user].path)
    } else { alert("Wrong PIN for "+user) }
  }

  return(
    <div className="min-h-screen bg-[#0f0a0d] text-white flex items-center justify-center p-6 relative">
      <div className="absolute top-0 w-[600px] h-[600px] bg-[#ff1846]/20 rounded-full blur-[120px] -translate-y-1/2" />
      <div className="bg-[#1a1218] border border-white/10 rounded-[32px] p-8 w-full max-w-sm z-10">
        <div className="text-center">
          <h1 className="text-3xl font-black">Secure Login</h1>
          <p className="text-white/50 text-xs mt-2 tracking-widest">DOLLY OS • STAFF ONLY</p>
        </div>

        <div className="mt-8 grid grid-cols-2 gap-2">
          {Object.keys(USERS).map(k=>(
            <button key={k} onClick={()=>setUser(k)} className={`rounded-full py-3 text-sm font-bold border ${user===k?'bg-[#ff1846] border-[#ff1846]':'bg-[#2a1e25] border-white/5'}`}>{USERS[k].icon} {k.toUpperCase()}</button>
          ))}
        </div>

        <div className="mt-6 bg-[#2a1e25] rounded-full px-2 py-2 flex items-center border border-white/5">
          <span className="pl-4 text-white/40 text-sm">{user}@dolly-os</span>
          <input value={pin} onChange={e=>setPin(e.target.value)} placeholder="Enter PIN" type="password" className="flex-1 bg-transparent text-center outline-none py-2" />
        </div>

        <button onClick={login} className="mt-6 w-full bg-white text-black rounded-full py-4 font-black">LOGIN → {USERS[user].label}</button>

        <div className="mt-8 bg-black/30 rounded-2xl p-4 text-[11px] text-white/40">
          <p className="font-bold text-white/60 mb-2">DEMO CREDENTIALS (for you only):</p>
          <p>waiter / WAIT123</p>
          <p>kitchen / KITCHEN123</p>
          <p>manager / MANAGER123</p>
          <p>admin / DOLLY@2026</p>
        </div>

        <button onClick={()=>router.push("/")} className="w-full mt-4 text-white/30 text-xs">← Back to Demo Page</button>
      </div>
    </div>
  )
}
