"use client"
import { useState } from "react"
import { useRouter } from "next/navigation"
export default function LaunchPage(){
  const [show,setShow]=useState(false)
  const router=useRouter()
  const roles=[
    {id:"waiter",label:"Waiter • Order",icon:"🍽️",path:"/waiter"},
    {id:"kitchen",label:"Kitchen",icon:"👨‍🍳",path:"/kitchen"},
    {id:"manager",label:"Manager",icon:"👔",path:"/manager"},
  ]
  return(
    <div className="min-h-screen bg-[#0f0a0d] text-white flex flex-col items-center justify-center p-6 relative">
      <div className="absolute top-0 w-[600px] h-[600px] bg-[#ff1846]/20 rounded-full blur-[120px] -translate-y-1/2" />
      <div className="w-full max-w-md bg-[#1c1219] border border-white/5 rounded-full px-4 py-3 flex justify-between items-center mb-10 z-10">
        <span className="text-[12px] font-bold tracking-wider">♥ DOLLY OS • LIVE DB</span>
        <span className="bg-[#2a1e25] w-8 h-8 rounded-full flex items-center justify-center">♥</span>
      </div>
      <div className="text-center max-w-md w-full z-10">
        <h1 className="text-6xl font-black">Dolly</h1>
        <p className="text-white/60 mt-3 text-sm tracking-[0.3em]">WE ARE LAUNCHING SOON</p>
        <div className="mt-12 bg-[#1a1218] border border-white/10 rounded-[28px] p-8">
          <h2 className="text-xl font-bold">Restaurant OS of the Future</h2>
          <p className="text-white/50 text-sm mt-2">Waiter, Kitchen & Billing — All in one.</p>
          <button onClick={()=>setShow(true)} className="mt-8 w-full bg-[#ff1846] rounded-full py-4 font-bold text-lg">Enter Demo →</button>
          <p className="text-white/30 text-[11px] mt-4">FOR CLIENTS • NO SIGNUP</p>
        </div>
      </div>
      {show && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-4 z-50">
          <div className="bg-[#1a1218] border border-white/10 rounded-[28px] p-6 w-full max-w-sm">
            <div className="flex justify-between items-center mb-6">
              <h3 className="font-bold text-sm">SELECT ROLE - CLIENT DEMO</h3>
              <button onClick={()=>setShow(false)} className="bg-white/10 rounded-full w-8 h-8">✕</button>
            </div>
            <div className="space-y-3">
              {roles.map(r=>(
                <button key={r.id} onClick={()=>router.push(r.path)} className={`w-full rounded-full py-4 font-bold flex items-center justify-center gap-2 ${r.id==='waiter'?'bg-[#ff1846]':'bg-[#2a1e25]'} border border-white/5`}>
                  <span>{r.icon}</span> {r.label} →
                </button>
              ))}
            </div>
            <p className="text-center text-white/30 text-xs mt-5">Admin Access is Private</p>
          </div>
        </div>
      )}
    </div>
  )
}
