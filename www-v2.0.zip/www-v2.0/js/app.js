const SUPABASE_URL='https://iwlrtixduzmoeyjwkqti.supabase.co';
const SUPABASE_KEY='sb_publishable_Wi-xuNnFMAFHjaqgh4GclA_Ill0sLTO';
const _sb = supabase.createClient(SUPABASE_URL, SUPABASE_KEY);
const DollyAuth={
 _cache:null,
 async getDB(){
  try{
   let [menuRes,tablesRes,ordersRes]=await Promise.all([
    _sb.from('menu_items').select('*').eq('restaurant_id','DEMO01'),
    _sb.from('tables_list').select('*').eq('restaurant_id','DEMO01'),
    _sb.from('orders').select('*').eq('restaurant_id','DEMO01').order('created_at',{ascending:false}).limit(100)
   ]);
   // Auto seed if menu empty
   if((!menuRes.data || menuRes.data.length===0)){
     const dishes=[
       {name:'Paneer Butter Masala',price:280,cat:'Main',veg:true},
       {name:'Dal Tadka',price:180,cat:'Main',veg:true},
       {name:'Chicken Biryani',price:350,cat:'Biryani',veg:false},
       {name:'Veg Biryani',price:250,cat:'Biryani',veg:true},
       {name:'Butter Naan',price:40,cat:'Bread',veg:true},
       {name:'Margherita Pizza',price:299,cat:'Pizza',veg:true},
       {name:'Chicken Pizza',price:399,cat:'Pizza',veg:false},
       {name:'Veg Manchurian',price:220,cat:'Starter',veg:true},
       {name:'Cold Coffee',price:120,cat:'Drinks',veg:true},
       {name:'Masala Dosa',price:150,cat:'South',veg:true}
     ];
     for(let d of dishes){ await _sb.from('menu_items').insert({restaurant_id:'DEMO01',...d}) }
     menuRes = await _sb.from('menu_items').select('*').eq('restaurant_id','DEMO01');
   }
   let mList=(menuRes.data||[]).map(m=>({id:m.id,name:m.name,price:m.price,cat:m.cat,veg:m.veg}));
   let tList=(tablesRes.data||[]).map(t=>({no:t.no,floor:t.floor,section:t.section,cap:t.cap}));
   let oList=(ordersRes.data||[]).map(o=>({id:Number(o.id),restId:o.restaurant_id,table:o.table_no,total:o.total,status:o.status,waiter:o.waiter,time:o.time,note:o.note,items:o.items||[]}));
   let db={restaurants:{'DEMO01':{id:'DEMO01',name:'Dolly Demo',menu:mList,tables:tList}},orders:oList};
   this._cache=db; return db;
  }catch(e){
   console.error(e);
   return {restaurants:{'DEMO01':{id:'DEMO01',name:'Dolly Demo',menu:[],tables:[]}},orders:[]};
  }
 },
 async saveOrder(order){
  let payload={id:order.id,restaurant_id:order.restId,table_no:order.table,total:order.total,status:order.status,waiter:order.waiter,time:order.time,note:order.note,items:order.items};
  let {error}=await _sb.from('orders').upsert(payload); this._cache=null; return !error;
 },
 async updateOrder(id,upd){
  let {error}=await _sb.from('orders').update(upd).eq('id',id); this._cache=null; return !error;
 },
 getSession(){try{return JSON.parse(localStorage.getItem('dolly_session'))}catch(e){return null}}
};
