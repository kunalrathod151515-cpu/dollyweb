(function(){
  const page = location.pathname.split('/').pop();
  const roleMap = { 'waiter.html':'waiter', 'kitchen.html':'kitchen', 'manager.html':'manager' };
  const need = roleMap[page];
  if(!need) return;
  const ok = localStorage.getItem('dolly_ok');
  const role = localStorage.getItem('dolly_role');
  if(ok !== 'yes'){ location.href='index.html'; return; }
  // allow same role OR admin OR any logged supabase user (Dipak case)
  if(role !== need && role !== 'admin' && role !== 'manager' && role !== 'waiter' && role !== 'kitchen'){
    // agar role manager.html me ja raha hai aur role = manager hai toh ok
    if(!(roleMap[page] === role)){
      // 1 sec wala redirect rokne ke liye - sirf tab redirect karo jab role bilkul alag ho
      // Dipak ka role manager hai toh manager.html allowed hai
      if(role !== need){ 
        console.log('Role mismatch but allowing because ok=yes. Saved role:',role,' need:',need);
        // comment next line to fully allow - for now allow
        // location.href='index.html';
      }
    }
  }
})();
