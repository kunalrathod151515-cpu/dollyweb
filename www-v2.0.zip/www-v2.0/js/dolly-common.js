function applyTheme(t){localStorage.setItem('dolly_theme',t);document.documentElement.setAttribute('data-theme',t)}
function toggleTheme(){applyTheme((localStorage.getItem('dolly_theme')||'dark')==='dark'?'light':'dark')}
function logout(){localStorage.removeItem('dolly_session');location.href='index.html'}
