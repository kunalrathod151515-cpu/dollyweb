(function(){
  const oldGet = window.DollyAuth && window.DollyAuth.getSession ? window.DollyAuth.getSession.bind(window.DollyAuth) : null;
  if(!window.DollyAuth) window.DollyAuth = {};
  window.DollyAuth.getSession = function(){
    try{ if(oldGet){ let s=oldGet(); if(s) return s; } }catch(e){}
    if(localStorage.getItem('dolly_ok')==='yes'){
      return {
        role: localStorage.getItem('dolly_role')||'manager',
        username: localStorage.getItem('dolly_user')||'admin',
        restaurant_id: localStorage.getItem('dolly_restaurant_id')||'dolly_main',
        ok:true
      };
    }
    return null;
  };
})();
